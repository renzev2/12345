UPDATE `global_reg_value` SET `value` = (`value` - `account_id` - 1337) WHERE `str` = '#kafra_code';
