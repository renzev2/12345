ALTER TABLE `chatlog` CHANGE `message` `message` VARCHAR( 255 ) NOT NULL
