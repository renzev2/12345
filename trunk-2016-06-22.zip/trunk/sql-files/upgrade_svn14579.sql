ALTER TABLE `ragsrvinfo` DROP `motd`;
