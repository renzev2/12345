DELETE FROM `global_reg_value` WHERE `str` = 'killedrid' OR `str` = 'killerrid';
